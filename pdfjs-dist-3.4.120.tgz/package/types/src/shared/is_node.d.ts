export const isNodeJS: any;
